/**
 * Enterprise Scanner Security Assessment JavaScript
 * Interactive cybersecurity evaluation for Fortune 500 companies
 */

class SecurityAssessment {
    constructor() {
        this.currentStep = 1;
        this.totalSteps = 6;
        this.formData = {};
        this.riskScore = 0;
        this.recommendations = [];
        
        this.init();
    }

    init() {
        this.attachEventListeners();
        this.updateProgress();
        this.loadFormData();
        
        // Track assessment start
        this.trackEvent('assessment_started');
    }

    attachEventListeners() {
        // Navigation buttons
        document.getElementById('next-step').addEventListener('click', () => {
            this.nextStep();
        });

        document.getElementById('prev-step').addEventListener('click', () => {
            this.previousStep();
        });

        document.getElementById('submit-assessment').addEventListener('click', (e) => {
            e.preventDefault();
            this.submitAssessment();
        });

        // Form validation
        document.getElementById('security-assessment-form').addEventListener('change', () => {
            this.saveFormData();
            this.validateCurrentStep();
        });

        // Download report
        document.getElementById('download-report').addEventListener('click', () => {
            this.downloadReport();
        });

        // Checkbox limit for security concerns
        this.limitCheckboxes('input[type="checkbox"][value*="data-breach"], input[type="checkbox"][value*="ransomware"], input[type="checkbox"][value*="insider-threats"], input[type="checkbox"][value*="phishing"], input[type="checkbox"][value*="cloud-security"], input[type="checkbox"][value*="compliance-gaps"]', 3);
    }

    nextStep() {
        if (this.validateCurrentStep()) {
            if (this.currentStep < this.totalSteps) {
                this.currentStep++;
                this.showStep(this.currentStep);
                this.updateProgress();
                this.updateNavigation();
                
                // Track step completion
                this.trackEvent('assessment_step_completed', { step: this.currentStep - 1 });
            }
        }
    }

    previousStep() {
        if (this.currentStep > 1) {
            this.currentStep--;
            this.showStep(this.currentStep);
            this.updateProgress();
            this.updateNavigation();
        }
    }

    showStep(stepNumber) {
        // Hide all steps
        document.querySelectorAll('.assessment-step').forEach(step => {
            step.classList.remove('active');
        });

        // Show current step
        const currentStepElement = document.querySelector(`[data-step="${stepNumber}"]`);
        if (currentStepElement) {
            currentStepElement.classList.add('active');
            
            // Scroll to top of form
            currentStepElement.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    }

    updateProgress() {
        const progressBar = document.getElementById('assessment-progress');
        const currentStepSpan = document.getElementById('current-step');
        
        const progressPercentage = ((this.currentStep - 1) / (this.totalSteps - 1)) * 100;
        
        progressBar.style.width = `${progressPercentage}%`;
        currentStepSpan.textContent = this.currentStep - 1;
        
        // Add completion animation
        if (progressPercentage === 100) {
            progressBar.classList.add('bg-success');
        }
    }

    updateNavigation() {
        const prevBtn = document.getElementById('prev-step');
        const nextBtn = document.getElementById('next-step');
        const submitBtn = document.getElementById('submit-assessment');

        // Show/hide previous button
        prevBtn.style.display = this.currentStep > 1 ? 'block' : 'none';

        // Show/hide next vs submit button
        if (this.currentStep === this.totalSteps) {
            nextBtn.style.display = 'none';
            submitBtn.style.display = 'block';
        } else {
            nextBtn.style.display = 'block';
            submitBtn.style.display = 'none';
        }
    }

    validateCurrentStep() {
        const currentStepElement = document.querySelector(`[data-step="${this.currentStep}"]`);
        const requiredFields = currentStepElement.querySelectorAll('[required]');
        let isValid = true;

        // Remove previous error states
        currentStepElement.querySelectorAll('.is-invalid').forEach(field => {
            field.classList.remove('is-invalid');
        });

        // Validate required fields
        requiredFields.forEach(field => {
            if (!field.value.trim()) {
                field.classList.add('is-invalid');
                isValid = false;
            }
        });

        // Step-specific validations
        if (this.currentStep === 2) {
            // Ensure at least one radio button is selected in security team question
            const securityTeamRadios = currentStepElement.querySelectorAll('input[name="security-team"]');
            const securityTeamSelected = Array.from(securityTeamRadios).some(radio => radio.checked);
            
            if (!securityTeamSelected) {
                this.showValidationError('Please indicate if you have a dedicated cybersecurity team.');
                isValid = false;
            }
        }

        if (this.currentStep === 5) {
            // Ensure security incident question is answered
            const incidentRadios = currentStepElement.querySelectorAll('input[name="security-incident"]');
            const incidentSelected = Array.from(incidentRadios).some(radio => radio.checked);
            
            if (!incidentSelected) {
                this.showValidationError('Please indicate your recent security incident history.');
                isValid = false;
            }
        }

        return isValid;
    }

    showValidationError(message) {
        // Create or update validation message
        let errorDiv = document.querySelector('.validation-error');
        if (!errorDiv) {
            errorDiv = document.createElement('div');
            errorDiv.className = 'validation-error alert alert-danger mt-3';
            document.querySelector(`[data-step="${this.currentStep}"]`).appendChild(errorDiv);
        }
        errorDiv.textContent = message;
        
        // Remove after 5 seconds
        setTimeout(() => {
            if (errorDiv) errorDiv.remove();
        }, 5000);
    }

    limitCheckboxes(selector, maxSelections) {
        const checkboxes = document.querySelectorAll(selector);
        
        checkboxes.forEach(checkbox => {
            checkbox.addEventListener('change', () => {
                const checkedBoxes = document.querySelectorAll(`${selector}:checked`);
                
                if (checkedBoxes.length > maxSelections) {
                    checkbox.checked = false;
                    this.showValidationError(`Please select up to ${maxSelections} options only.`);
                }
            });
        });
    }

    saveFormData() {
        const form = document.getElementById('security-assessment-form');
        const formData = new FormData(form);
        
        // Convert FormData to object
        this.formData = {};
        for (let [key, value] of formData.entries()) {
            if (this.formData[key]) {
                // Handle multiple values (checkboxes)
                if (Array.isArray(this.formData[key])) {
                    this.formData[key].push(value);
                } else {
                    this.formData[key] = [this.formData[key], value];
                }
            } else {
                this.formData[key] = value;
            }
        }

        // Save additional form values not captured by FormData
        this.formData.companyName = document.getElementById('company-name').value;
        this.formData.industry = document.getElementById('industry').value;
        this.formData.companySize = document.getElementById('company-size').value;
        this.formData.annualRevenue = document.getElementById('annual-revenue').value;
        this.formData.contactName = document.getElementById('contact-name').value;
        this.formData.jobTitle = document.getElementById('job-title').value;
        this.formData.email = document.getElementById('email').value;
        this.formData.phone = document.getElementById('phone').value;

        // Save to localStorage
        localStorage.setItem('enterpriseAssessmentData', JSON.stringify(this.formData));
    }

    loadFormData() {
        const savedData = localStorage.getItem('enterpriseAssessmentData');
        if (savedData) {
            this.formData = JSON.parse(savedData);
            this.populateForm();
        }
    }

    populateForm() {
        // Populate form fields with saved data
        Object.keys(this.formData).forEach(key => {
            const element = document.getElementById(key) || document.querySelector(`[name="${key}"]`);
            if (element) {
                if (element.type === 'checkbox' || element.type === 'radio') {
                    if (Array.isArray(this.formData[key])) {
                        this.formData[key].forEach(value => {
                            const checkbox = document.querySelector(`[name="${key}"][value="${value}"]`);
                            if (checkbox) checkbox.checked = true;
                        });
                    } else {
                        const input = document.querySelector(`[name="${key}"][value="${this.formData[key]}"]`);
                        if (input) input.checked = true;
                    }
                } else {
                    element.value = this.formData[key];
                }
            }
        });
    }

    async submitAssessment() {
        if (!this.validateCurrentStep()) {
            return;
        }

        // Show loading state
        const submitBtn = document.getElementById('submit-assessment');
        const originalText = submitBtn.innerHTML;
        submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Analyzing...';
        submitBtn.disabled = true;

        try {
            // Calculate risk assessment
            this.calculateRiskScore();
            this.generateRecommendations();

            // Send data to backend
            const response = await fetch('/api/security-assessment', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    formData: this.formData,
                    riskScore: this.riskScore,
                    recommendations: this.recommendations,
                    timestamp: new Date().toISOString()
                })
            });

            const result = await response.json();

            if (response.ok) {
                // Show results
                this.displayResults();
                
                // Track completion
                this.trackEvent('assessment_completed', {
                    risk_score: this.riskScore,
                    company_size: this.formData.companySize,
                    industry: this.formData.industry
                });

                // Clear saved data
                localStorage.removeItem('enterpriseAssessmentData');
            } else {
                throw new Error(result.message || 'Assessment submission failed');
            }

        } catch (error) {
            console.error('Assessment submission error:', error);
            this.showValidationError('Unable to process assessment. Please try again or contact support.');
        } finally {
            // Reset button
            submitBtn.innerHTML = originalText;
            submitBtn.disabled = false;
        }
    }

    calculateRiskScore() {
        let score = 100; // Start with perfect score
        
        // Company size factor (larger = more complex = higher risk)
        const sizeFactors = {
            'startup': 0,
            'small': -5,
            'medium': -10,
            'large': -15,
            'enterprise': -20
        };
        score += sizeFactors[this.formData.companySize] || 0;

        // Security team factor
        const teamFactors = {
            'yes': 15,
            'partial': 5,
            'no': -25
        };
        score += teamFactors[this.formData['security-team']] || 0;

        // Security incident history
        const incidentFactors = {
            'no': 10,
            'yes-minor': -10,
            'yes-major': -30,
            'unsure': -15
        };
        score += incidentFactors[this.formData['security-incident']] || 0;

        // Assessment frequency
        const assessmentFactors = {
            'quarterly': 15,
            'annually': 5,
            'rarely': -20
        };
        score += assessmentFactors[this.formData['assessment-frequency']] || 0;

        // Compliance status
        const complianceFactors = {
            'fully-compliant': 20,
            'mostly-compliant': 10,
            'working-towards': -5,
            'not-compliant': -25
        };
        score += complianceFactors[this.formData['compliance-status']] || 0;

        // Industry-specific adjustments
        const industryRisks = {
            'financial': -10,
            'healthcare': -15,
            'government': -10,
            'technology': -5,
            'retail': -8,
            'manufacturing': -5,
            'energy': -12,
            'education': -3
        };
        score += industryRisks[this.formData.industry] || 0;

        // Ensure score is within bounds
        this.riskScore = Math.max(0, Math.min(100, score));
    }

    generateRecommendations() {
        this.recommendations = [];

        // Security team recommendations
        if (this.formData['security-team'] === 'no') {
            this.recommendations.push({
                title: 'Establish Dedicated Security Team',
                description: 'Organizations without dedicated cybersecurity teams face 3x higher breach risk. Consider hiring or outsourcing security expertise.',
                priority: 'high',
                impact: 'High',
                timeframe: '1-3 months'
            });
        }

        // Incident history recommendations
        if (this.formData['security-incident'] === 'yes-major') {
            this.recommendations.push({
                title: 'Incident Response Plan Review',
                description: 'Recent major incidents indicate gaps in your security posture. Conduct thorough post-incident analysis and strengthen defenses.',
                priority: 'high',
                impact: 'High',
                timeframe: 'Immediate'
            });
        }

        // Assessment frequency recommendations
        if (this.formData['assessment-frequency'] === 'rarely') {
            this.recommendations.push({
                title: 'Regular Security Assessments',
                description: 'Implement quarterly security assessments to maintain visibility into your threat landscape and compliance status.',
                priority: 'medium',
                impact: 'Medium',
                timeframe: '1-2 months'
            });
        }

        // Compliance recommendations
        if (this.formData['compliance-status'] === 'not-compliant') {
            this.recommendations.push({
                title: 'Compliance Framework Implementation',
                description: 'Establish compliance with relevant frameworks (NIST, ISO 27001) to reduce regulatory risk and improve security posture.',
                priority: 'high',
                impact: 'High',
                timeframe: '3-6 months'
            });
        }

        // Industry-specific recommendations
        if (this.formData.industry === 'financial') {
            this.recommendations.push({
                title: 'Financial Services Security Controls',
                description: 'Implement enhanced controls for financial data protection, including encryption, access management, and fraud detection.',
                priority: 'high',
                impact: 'High',
                timeframe: '2-4 months'
            });
        }

        // Default recommendations for low scores
        if (this.riskScore < 60) {
            this.recommendations.push({
                title: 'Comprehensive Security Program',
                description: 'Your assessment indicates significant security gaps. Consider implementing a comprehensive cybersecurity program with Enterprise Scanner.',
                priority: 'high',
                impact: 'Critical',
                timeframe: 'Immediate'
            });
        }

        // Ensure we have at least 3 recommendations
        if (this.recommendations.length < 3) {
            this.recommendations.push(
                {
                    title: 'Security Awareness Training',
                    description: 'Implement regular cybersecurity training for all employees to reduce human error and phishing susceptibility.',
                    priority: 'medium',
                    impact: 'Medium',
                    timeframe: '1-2 months'
                },
                {
                    title: 'Backup and Recovery Plan',
                    description: 'Establish robust backup procedures and test recovery capabilities to ensure business continuity.',
                    priority: 'medium',
                    impact: 'Medium',
                    timeframe: '2-3 months'
                }
            );
        }
    }

    displayResults() {
        // Generate results HTML
        const resultsHTML = this.generateResultsHTML();
        
        // Insert into modal
        document.getElementById('assessment-results').innerHTML = resultsHTML;
        
        // Show modal
        const modal = new bootstrap.Modal(document.getElementById('results-modal'));
        modal.show();
    }

    generateResultsHTML() {
        const riskLevel = this.getRiskLevel(this.riskScore);
        const riskClass = riskLevel.toLowerCase();
        
        return `
            <div class="risk-score-container">
                <div class="risk-score-card">
                    <div class="risk-score ${riskClass}">${this.riskScore}</div>
                    <div class="risk-label">Overall Security Score</div>
                </div>
                <div class="risk-score-card">
                    <div class="risk-score ${riskClass}">${riskLevel}</div>
                    <div class="risk-label">Risk Level</div>
                </div>
                <div class="risk-score-card">
                    <div class="risk-score text-primary">${this.formData.industry || 'General'}</div>
                    <div class="risk-label">Industry</div>
                </div>
                <div class="risk-score-card">
                    <div class="risk-score text-info">${this.formData.companySize || 'Unknown'}</div>
                    <div class="risk-label">Company Size</div>
                </div>
            </div>
            
            <div class="alert alert-info">
                <h5><i class="bi bi-info-circle me-2"></i>Assessment Summary</h5>
                <p>Based on your responses, your organization has a <strong>${riskLevel.toLowerCase()}</strong> security risk profile. 
                ${this.getScoreSummary(this.riskScore)}</p>
            </div>
            
            <div class="recommendations-section">
                <h4 class="mb-3"><i class="bi bi-lightbulb me-2"></i>Recommended Actions</h4>
                ${this.recommendations.map((rec, index) => `
                    <div class="recommendation-item priority-${rec.priority}">
                        <h5>${rec.title}</h5>
                        <p>${rec.description}</p>
                        <div class="row">
                            <div class="col-sm-4"><strong>Priority:</strong> ${rec.priority.charAt(0).toUpperCase() + rec.priority.slice(1)}</div>
                            <div class="col-sm-4"><strong>Impact:</strong> ${rec.impact}</div>
                            <div class="col-sm-4"><strong>Timeframe:</strong> ${rec.timeframe}</div>
                        </div>
                    </div>
                `).join('')}
            </div>
            
            <div class="alert alert-success">
                <h5><i class="bi bi-shield-check me-2"></i>Next Steps</h5>
                <p>Schedule a consultation with our Enterprise Scanner security experts to discuss how we can help 
                improve your cybersecurity posture and achieve compliance goals. Our Fortune 500 clients typically 
                see 300-800% ROI within the first year.</p>
            </div>
        `;
    }

    getRiskLevel(score) {
        if (score >= 85) return 'Excellent';
        if (score >= 70) return 'Good';
        if (score >= 55) return 'Fair';
        if (score >= 40) return 'Poor';
        return 'Critical';
    }

    getScoreSummary(score) {
        if (score >= 85) {
            return 'Your organization demonstrates strong security practices with comprehensive controls in place.';
        } else if (score >= 70) {
            return 'Your security posture is solid with some areas for improvement to achieve enterprise-grade protection.';
        } else if (score >= 55) {
            return 'Your security program has basic protections but requires significant enhancements to meet enterprise standards.';
        } else if (score >= 40) {
            return 'Your organization faces considerable security risks that require immediate attention and investment.';
        } else {
            return 'Your current security posture presents critical vulnerabilities that could result in significant business impact.';
        }
    }

    downloadReport() {
        // Track download
        this.trackEvent('report_downloaded', {
            risk_score: this.riskScore,
            company: this.formData.companyName
        });

        // Generate PDF report (simplified version)
        const reportContent = this.generatePDFContent();
        
        // Create downloadable content
        const blob = new Blob([reportContent], { type: 'text/html' });
        const url = URL.createObjectURL(blob);
        
        const link = document.createElement('a');
        link.href = url;
        link.download = `Enterprise_Security_Assessment_${this.formData.companyName || 'Report'}_${new Date().toISOString().split('T')[0]}.html`;
        
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
        URL.revokeObjectURL(url);
    }

    generatePDFContent() {
        return `
<!DOCTYPE html>
<html>
<head>
    <title>Enterprise Security Assessment Report</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; }
        .header { text-align: center; margin-bottom: 40px; }
        .score { font-size: 48px; font-weight: bold; color: #1e3c72; }
        .section { margin: 30px 0; }
        .recommendation { margin: 20px 0; padding: 15px; border-left: 4px solid #1e3c72; }
        .high-priority { border-left-color: #dc3545; }
        .medium-priority { border-left-color: #ffc107; }
        .low-priority { border-left-color: #28a745; }
    </style>
</head>
<body>
    <div class="header">
        <h1>Enterprise Security Assessment Report</h1>
        <h2>${this.formData.companyName || 'Organization'}</h2>
        <div class="score">${this.riskScore}/100</div>
        <p>Risk Level: ${this.getRiskLevel(this.riskScore)}</p>
        <p>Assessment Date: ${new Date().toLocaleDateString()}</p>
    </div>
    
    <div class="section">
        <h3>Executive Summary</h3>
        <p>${this.getScoreSummary(this.riskScore)}</p>
    </div>
    
    <div class="section">
        <h3>Recommendations</h3>
        ${this.recommendations.map(rec => `
            <div class="recommendation ${rec.priority}-priority">
                <h4>${rec.title}</h4>
                <p>${rec.description}</p>
                <p><strong>Priority:</strong> ${rec.priority} | <strong>Impact:</strong> ${rec.impact} | <strong>Timeframe:</strong> ${rec.timeframe}</p>
            </div>
        `).join('')}
    </div>
    
    <div class="section">
        <h3>Next Steps</h3>
        <p>Contact Enterprise Scanner for a detailed consultation:</p>
        <p>Email: <a href="mailto:sales@enterprisescanner.com">sales@enterprisescanner.com</a></p>
        <p>Website: <a href="https://enterprisescanner.com">https://enterprisescanner.com</a></p>
    </div>
    
    <footer style="margin-top: 50px; text-align: center; color: #666;">
        <p>This report was generated by Enterprise Scanner's Security Assessment Tool</p>
        <p>© ${new Date().getFullYear()} Enterprise Scanner. All rights reserved.</p>
    </footer>
</body>
</html>`;
    }

    trackEvent(eventName, data = {}) {
        // Analytics tracking
        if (typeof gtag !== 'undefined') {
            gtag('event', eventName, {
                event_category: 'security_assessment',
                ...data
            });
        }

        // Console logging for development
        console.log('Assessment Event:', eventName, data);
    }
}

// Initialize assessment when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    window.securityAssessment = new SecurityAssessment();
});