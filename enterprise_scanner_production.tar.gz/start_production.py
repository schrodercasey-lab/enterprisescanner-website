#!/usr/bin/env python3
"""
Enterprise Scanner - Simple Production Startup Script
Starts the application for immediate production use
"""

import os
import sys
from dotenv import load_dotenv

# Set up paths
WORKSPACE_ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, WORKSPACE_ROOT)
sys.path.insert(0, os.path.join(WORKSPACE_ROOT, 'backend'))

# Load simplified production environment
load_dotenv('.env.production.simple')

# Set Flask environment
os.environ['FLASK_ENV'] = 'production'
os.environ['RATE_LIMITING_ENABLED'] = 'False'

print("Starting Enterprise Scanner in Simple Production Mode...")
print("Database: SQLite Production")
print("Security: Enabled (simplified)")
print("Rate Limiting: Disabled")
print("Redis: Disabled")
print("URL: http://localhost:5000")
print("CRM Dashboard: http://localhost:5000/crm-dashboard.html")
print()

# Start the application
if __name__ == '__main__':
    from backend.app import app
    
    # Configure Flask for production
    app.config['DEBUG'] = False
    app.config['TESTING'] = False
    
    # Start server
    print("Enterprise Scanner started successfully!")
    print("Access the CRM dashboard at: http://localhost:5000/crm-dashboard.html")
    
    app.run(
        host='0.0.0.0',
        port=5000,
        debug=False,
        threaded=True
    )
